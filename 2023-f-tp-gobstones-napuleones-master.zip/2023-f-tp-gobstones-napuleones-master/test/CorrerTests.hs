import Spec
import PdePreludat

-- NO TOCAR
-- Si querés ver los tests tenés que ir a `src/Spec.hs`
main :: IO ()
main = correrTests
-- NO TOCAR